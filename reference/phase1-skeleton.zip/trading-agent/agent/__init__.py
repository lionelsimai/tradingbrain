"""Trading agent package."""
